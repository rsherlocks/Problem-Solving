#include<stdio.h>
int main()
{
    int a[10]={5,6,8,9,10,11,5,6,3,7},i;
    for(i=0;i<10;i++)
    {
        printf("index= %d & element =%d\n",i,a[i]);
    }
    return 0;
}
